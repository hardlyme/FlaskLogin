from myproject import db,login_manager, app
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import UserMixin
from itsdangerous import URLSafeSerializer, SignatureExpired, TimedSerializer

# The user_loader decorator allows flask-login to load the current user
# and grab their id.
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)

class User(db.Model, UserMixin):

    # Create a table in the db
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key = True)
    email = db.Column(db.String(64), unique=True, index=True)
    password_hash = db.Column(db.String(128))
    username = db.Column(db.String(64), unique=True, index=True)
    # registered_on = db.Column(db.DateTime, nullable=False)
    confirmed = db.Column(db.Boolean, nullable=False, default=False)
    # confirmed_on = db.Column(db.DateTime, nullable=True)

    # def __init__(self, email, password, username, registered_on, confirmed, confirmed_on=None):
    def __init__(self, email, password, username):
        self.email = email
        self.password_hash = generate_password_hash(password)
        self.username = username
        # self.registered_on = registered_on
        # self.confirmed = confirmed
        # self.confirmed_on = confirmed_on

    def check_password(self, password):
        # https://stackoverflow.com/questions/23432478/flask-generate-password-hash-not-constant-output
        return check_password_hash(self.password_hash, password)

    def returnfalse(self, email):
        self.email = email
        return self.email

    def generate_confirmation_token(self):
        s = TimedSerializer(app.config['SECRET_KEY'], 'confirmation')
        return s.dumps(self.id)

    def confirm(self, token, max_age = 3600):
        s = TimedSerializer(app.config['SECRET_KEY'])
        try:
            data = s.loads(token, max_age=max_age)
        except:
            return False
        if data != self.id:
            return False
        self.confirmed = True
        db.session.add(self)
        return True
        # try:
        #     email = s.loads(token, max_age=max_age)
        # except:
        #     return False
        # return email

