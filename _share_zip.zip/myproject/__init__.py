import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_mail import Mail, Message

# Create a login manager object
login_manager = LoginManager()

app = Flask(__name__)
# Often people will also separate these into a separate config.py file
# app.config['SECRET_KEY'] = 'mysecretkey'
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SECRET_KEY'] = 'mysecretkey'
# app.config['SECURITY_PASSWORD_SALT'] =
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'data.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#########################################################################
app.config['MAIL_SERVER'] = 'smtp.XXX.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'XXX.com'  # enter your email here
app.config['MAIL_DEFAULT_SENDER'] = 'XXX.com' # enter your email here
app.config['MAIL_PASSWORD'] = 'XXX' # enter your password here
app.config['MAIL_SUPRESS_SEND'] = False
app.config['MAIL_MAX_EMAILS'] = None
app.config['DEBUG'] = True
app.config['TESTING'] = False
app.config['MAIL_ASCII_ATTACHMENTS'] = False

mail = Mail(app)
###########################################################################


db = SQLAlchemy(app)
Migrate(app,db)

# We can now pass in our app to the login manager
login_manager.init_app(app)

# Tell users what view to go to when they need to login.
login_manager.login_view = "login"