import numpy as np
from myproject import app,db
from flask import render_template, redirect, request, url_for, flash, Markup
from flask_login import login_user,login_required,logout_user, current_user
from myproject.models import User
from myproject.forms import LoginForm, RegistrationForm
from itsdangerous import URLSafeSerializer, SignatureExpired
from flask_mail import Mail, Message
import datetime

s = URLSafeSerializer(app.config['SECRET_KEY'])
mail = Mail(app)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/welcome')
@login_required
def welcome_user():
    return render_template('welcome_user.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You logged out!')
    return redirect(url_for('home'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'POST' and form.validate():
        user = User.query.filter_by(email=form.email.data).first()
        # name = User.query.filter_by(username=form.username.data).first()
        if user is None:
            email1 = form.email.data
            flash(f'No account not found with user name: {email1}! Please register your account in order to proceed!')
            return redirect(url_for('register'))

        if user.check_password(password = form.password.data):
            login_user(user)
            flash('Logged in successfully.')
            next = request.args.get('next')
            if next == None or not next[0] == '/':
                next = url_for('profile')

            return redirect(next)

    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm(request.form)
    if request.method == 'POST' and form.validate():
        print(form.username.data)
        user = User(email=form.email.data,
                    username=form.username.data,
                    password=form.password.data
                    )
        db.session.add(user)
        db.session.commit()
        flash(f'Thanks for registering! The email you entered is {form.email.data}. An email with a link to authenticate your account is on its way.'
              f'Once the authentication is complete, you may login and start using our website.')
        # s = URLSafeSerializer(app.config['SECRET_KEY'])
        # token = s.dumps(form.email.data, salt = 'email-confirm')
        token = user.generate_confirmation_token()
        emailhere = form.email.data
        msg = Message('Confirm Email', sender='XXX.com', recipients=[emailhere])
        link = url_for('confirm', token = token, _external= True)
        msg.body = 'Your link is {}'.format(link)
        mail.send(msg)
        flash(
            f'Thanks for registering! The email you entered is {emailhere}. '
            f'An email with a link to authenticate your account is on its way.')

        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/confirm/<token>')
@login_required
def confirm(token):
    print(current_user)
    if current_user.confirmed:
        return redirect(url_for('/'))
    if current_user.confirm(token):
        db.session.commit()
        flash('You have confirmed your account. Thanks!')
    else:
        flash('The confirmation link is invalid or has expired.')
    return redirect(url_for('/'))
    #######


@app.route('/functionality', methods=['GET', 'POST'])
@login_required
def functionality():
    plot_url = str()
    if request.method == 'GET':
    return render_template('functionality.html')

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    name = str()
    email = str()
    if request.method == 'GET':
        name = current_user.username
        email = current_user.email
        return render_template('profile.html', ans = name, ans1 = email)

if __name__ == '__main__':
    app.run(debug=True)